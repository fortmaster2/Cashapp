## Cashapp V4


Steps 

It's reccomended to turn anti-virus off as this could mess up the program while it's trying to run. 

#######FULL VIDEO WILL BE POSTED SOON#######


(1) ~ Turn Anti-Virus off (or keep it on and see if it works) 

(2) ~ login to the official cashapp website (https://cash.app) MAKE SURE THAT IT'S THE RIGHT ONE!!!

(3) ~ once you login confirm your in the right account that you want to edit the money on

(4) ~ open the cashapp.exe

(5) ~ make sure you are logged in ()

(6) ~ once you do that  you can now edit the amount!

(7) ~ Share with your friends ~ 


If there is a problem please message my discord! 

sgote3 

Alt is used to avoid being banned!