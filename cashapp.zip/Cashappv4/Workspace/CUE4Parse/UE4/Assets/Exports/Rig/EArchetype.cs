﻿namespace CUE4Parse.UE4.Assets.Exports.Rig
{
    public enum EArchetype : byte
    {
        Asian,
        Black,
        Caucasian,
        Hispanic,
        Alien,
        Other
    }
}
