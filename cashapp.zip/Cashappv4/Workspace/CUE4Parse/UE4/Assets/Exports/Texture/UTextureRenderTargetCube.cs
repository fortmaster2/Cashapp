namespace CUE4Parse.UE4.Assets.Exports.Texture;

public class UTextureRenderTargetCube : UTextureRenderTarget { }
