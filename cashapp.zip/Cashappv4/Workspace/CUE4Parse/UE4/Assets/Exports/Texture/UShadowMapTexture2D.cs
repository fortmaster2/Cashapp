namespace CUE4Parse.UE4.Assets.Exports.Texture;

public class UShadowMapTexture2D : UTexture2D { }
