﻿namespace CUE4Parse.UE4.Assets.Exports.Texture;

public class UVirtualTexture2D : UTexture2D { }
