﻿namespace CUE4Parse.UE4.Assets.Exports.GeometryCollection
{
    public enum EManagedArrayType : byte
    {
        FNoneType
    }
}
