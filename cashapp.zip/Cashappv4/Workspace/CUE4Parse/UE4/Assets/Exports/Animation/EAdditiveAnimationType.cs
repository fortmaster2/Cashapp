﻿namespace CUE4Parse.UE4.Assets.Exports.Animation
{
    public enum EAdditiveAnimationType
    {
        AAT_None,
        AAT_LocalSpaceBase,
        AAT_RotationOffsetMeshSpace,
        AAT_MAX
    }
}