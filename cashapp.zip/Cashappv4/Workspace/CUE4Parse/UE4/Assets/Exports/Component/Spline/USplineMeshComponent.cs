using CUE4Parse.UE4.Assets.Exports.Component.StaticMesh;

namespace CUE4Parse.UE4.Assets.Exports.Component.Spline
{
    public class USplineMeshComponent : UStaticMeshComponent { }
}