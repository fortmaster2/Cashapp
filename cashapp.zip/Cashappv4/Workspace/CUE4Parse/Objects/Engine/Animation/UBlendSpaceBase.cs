namespace CUE4Parse.UE4.Objects.Engine.Animation
{
    public class UBlendSpaceBase : UAnimationAsset
    {
    }
}
