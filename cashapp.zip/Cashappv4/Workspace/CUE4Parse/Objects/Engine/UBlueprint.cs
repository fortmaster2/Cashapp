namespace CUE4Parse.UE4.Objects.Engine
{
    public class UBlueprint : UBlueprintCore { }
}