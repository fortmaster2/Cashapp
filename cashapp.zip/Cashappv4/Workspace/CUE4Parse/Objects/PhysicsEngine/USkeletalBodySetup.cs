namespace CUE4Parse.UE4.Objects.PhysicsEngine
{
    public class USkeletalBodySetup : UBodySetup { }
}
