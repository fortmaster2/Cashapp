using CUE4Parse.UE4.Assets.Exports.Sound;

namespace CUE4Parse.GameTypes.FN.Assets.Exports.Sound
{
    public class UMusicPack : USoundCue { }

    public class UEmoteFoley : USoundCue { }

    public class UPickaxeImpactEnemy : USoundCue { }

    public class UPickaxeReady : USoundCue { }

    public class UPickaxeSwing : USoundCue { }

    public class UEmoteMusic : USoundCue { }
}
